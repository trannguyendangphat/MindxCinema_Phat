// Lấy các phần tử trong form
const signInForm = document.querySelector("form");
const emailInput = document.getElementById("Email");
const passwordInput = document.getElementById("Password");

// Thêm chỗ hiển thị thông báo (nếu muốn)
let messageBox = document.createElement("div");
messageBox.className = "mt-3";
signInForm.parentNode.appendChild(messageBox);

function checkSignIn(event) {
  event.preventDefault(); // chặn reload trang

  // 1. Lấy dữ liệu người dùng nhập
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  // 2. Lấy dữ liệu đã lưu trong localStorage khi Sign Up
  const savedData = localStorage.getItem("signupData");
  if (!savedData) {
    messageBox.className = "mt-3 text-danger";
    messageBox.textContent = "No account found. Please sign up first!";
    return;
  }

  const userData = JSON.parse(savedData);

  // 3. So khớp email + password
  if (email === userData.Email && password === userData.Password) {
    messageBox.className = "mt-3 text-success";
    messageBox.textContent = "Login successful! Redirecting...";

    // ví dụ chuyển tới trang chính
    setTimeout(() => {
      location.href = "Main.html"; // đổi sang trang bạn muốn
    }, 1000);
  } else {
    messageBox.className = "mt-3 text-danger";
    messageBox.textContent = "Incorrect email or password!";
  }
}

// 4. Gắn sự kiện submit
signInForm.addEventListener("submit", checkSignIn);
