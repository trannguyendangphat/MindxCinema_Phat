const genreForm = document.getElementById("genre-form");
const genreListEl = document.getElementById("genre-list");
const genreIdInput = document.getElementById("genre-id");
const genreNameInput = document.getElementById("genre-name");

// Load genres
let genres = JSON.parse(localStorage.getItem("genres")) || [];
renderGenreList();

// Thêm hoặc sửa genre
genreForm.addEventListener("submit", e => {
  e.preventDefault();
  const id = genreIdInput.value || Date.now().toString();
  const genre = { id, name: genreNameInput.value.trim() };

  const index = genres.findIndex(g => g.id === id);
  if (index >= 0) {
    genres[index] = genre; // sửa
  } else {
    genres.push(genre); // thêm mới
  }

  localStorage.setItem("genres", JSON.stringify(genres));
  genreForm.reset();
  genreIdInput.value = "";
  renderGenreList();

  // Quay về Home
  window.location.href = "Main.html";
});

// Render danh sách genre
function renderGenreList() {
  genreListEl.innerHTML = genres
    .map(genre => `
      <li class="list-group-item d-flex justify-content-between align-items-center">
        ${genre.name}
        <span>
          <button class="btn btn-sm btn-warning me-2" onclick="editGenre('${genre.id}')">Edit</button>
          <button class="btn btn-sm btn-danger" onclick="deleteGenre('${genre.id}')">Delete</button>
        </span>
      </li>
    `).join("");
}

// Edit genre
function editGenre(id) {
  const genre = genres.find(g => g.id === id);
  if (genre) {
    genreIdInput.value = genre.id;
    genreNameInput.value = genre.name;
  }
}

// Delete genre
function deleteGenre(id) {
  if (confirm("Are you sure to delete this genre?")) {
    genres = genres.filter(g => g.id !== id);
    localStorage.setItem("genres", JSON.stringify(genres));
    renderGenreList();
  }
}

// Expose functions cho button onclick
window.editGenre = editGenre;
window.deleteGenre = deleteGenre;
