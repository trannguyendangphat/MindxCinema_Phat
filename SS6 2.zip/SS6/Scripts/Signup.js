// Get html elements
const signUpForm = document.getElementById("signup-form");
const usernameInput = document.getElementById("username");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");

function checkSignUp(event) {
  event.preventDefault(); // ngăn submit trước

  // 1 Get data
  const email = emailInput.value.trim();
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();

  // 2 Validate data (thêm kiểm tra nếu muốn)

  // 3 Organize data
  const data = {
    Email: email,
    Username: username,
    Password: password
  };

  // 4 Save data
  localStorage.setItem("signupData", JSON.stringify(data));

  // 5 Redirect to Sign In page
  location.href = "SignIn.html";
}

// Connect event
signUpForm.addEventListener("submit", checkSignUp); // bỏ dấu () ở đây
