const API_KEY = "d24ed55ee6a59e81821ada5a68aed768";
const BASE_URL = "https://api.themoviedb.org/3";

// Lấy movie id từ URL
const urlParams = new URLSearchParams(window.location.search);
const movieId = urlParams.get("id");

const moviePlayerContainer = document.getElementById("movie-player");

if (movieId) {
  fetchMovieVideos(movieId);
}

// Lấy video/trailer của phim từ TMDB
async function fetchMovieVideos(id) {
  try {
    const res = await fetch(`${BASE_URL}/movie/${id}/videos?api_key=${API_KEY}&language=en-US`);
    const data = await res.json();
    displayVideo(data.results);
  } catch (err) {
    moviePlayerContainer.innerHTML = `<p class="text-danger">Error loading movie video!</p>`;
  }
}

function displayVideo(videos) {
  // Tìm trailer YouTube đầu tiên
  const trailer = videos.find(v => v.type === "Trailer" && v.site === "YouTube");

  if (trailer) {
    moviePlayerContainer.innerHTML = `
      <h2 class="mb-3">Watch Trailer</h2>
      <div class="ratio ratio-16x9">
        <iframe src="https://www.youtube.com/embed/${trailer.key}" title="YouTube video" allowfullscreen></iframe>
      </div>
      <a href="MovieDetail.html?id=${movieId}" class="btn btn_form mt-3">Back to Details</a>
    `;
  } else {
    moviePlayerContainer.innerHTML = `<p class="text-warning">No trailer available for this movie.</p>`;
  }
}
