const profileForm = document.getElementById("profile-form");
const usernameInput = document.getElementById("username");
const emailInput = document.getElementById("email");

// Load profile hiện tại
const profileData = JSON.parse(localStorage.getItem("signupData")) || {};
usernameInput.value = profileData.Username || "";
emailInput.value = profileData.Email || "";

// Khi submit form
profileForm.addEventListener("submit", function(e) {
  e.preventDefault();
  const updatedData = {
    Username: usernameInput.value.trim(),
    Email: emailInput.value.trim(),
    Password: profileData.Password || "" // giữ nguyên password
  };
  localStorage.setItem("signupData", JSON.stringify(updatedData));
  alert("Profile updated successfully!");
  // Quay về Home
  window.location.href = "Main.html";
});
