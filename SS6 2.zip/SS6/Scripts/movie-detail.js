const API_KEY = "d24ed55ee6a59e81821ada5a68aed768";
const BASE_URL = "https://api.themoviedb.org/3";
const IMAGE_URL = "https://image.tmdb.org/t/p/w500";

const movieDetailContainer = document.getElementById("movie-detail");

// Lấy id phim từ URL
const urlParams = new URLSearchParams(window.location.search);
const movieId = urlParams.get("id");

if (movieId) {
  fetchMovieDetail(movieId);
}

// ================== FETCH CHI TIẾT PHIM ==================
async function fetchMovieDetail(id) {
  try {
    const res = await fetch(`${BASE_URL}/movie/${id}?api_key=${API_KEY}&language=en-US`);
    const movie = await res.json();
    displayMovieDetail(movie);
  } catch (err) {
    movieDetailContainer.innerHTML = `<p class="text-danger">Error loading movie details!</p>`;
  }
}

// ================== HIỂN THỊ CHI TIẾT PHIM ==================
function displayMovieDetail(movie) {
  movieDetailContainer.innerHTML = `
    <div class="col-12 col-md-4">
      <img src="${IMAGE_URL}${movie.poster_path}" class="img-fluid rounded" alt="${movie.title}">
    </div>
    <div class="col-12 col-md-8">
      <h2>${movie.title}</h2>
      <p><strong>Release Date:</strong> ${movie.release_date}</p>
      <p><strong>Rating:</strong> ⭐ ${movie.vote_average}</p>
      <p><strong>Genres:</strong> ${movie.genres.map(g => g.name).join(", ")}</p>
      <p><strong>Overview:</strong> ${movie.overview}</p>

      <a href="MoviePlayer.html?id=${movie.id}" class="btn btn_form mt-3 me-2">Watch Trailer</a>
      <a href="Main.html" class="btn btn_form mt-3">Back to Home</a>
    </div>
  `;
}
