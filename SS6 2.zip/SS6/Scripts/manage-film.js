const filmForm = document.getElementById("film-form");
const filmListEl = document.getElementById("film-list");
const filmIdInput = document.getElementById("film-id");
const titleInput = document.getElementById("film-title");
const releaseInput = document.getElementById("film-release");
const ratingInput = document.getElementById("film-rating");

// Load films
let films = JSON.parse(localStorage.getItem("films")) || [];
renderFilmList();

// Thêm hoặc sửa film
filmForm.addEventListener("submit", e => {
  e.preventDefault();
  const id = filmIdInput.value || Date.now().toString();
  const film = {
    id,
    title: titleInput.value.trim(),
    release: releaseInput.value,
    rating: parseFloat(ratingInput.value)
  };

  const index = films.findIndex(f => f.id === id);
  if (index >= 0) {
    films[index] = film; // sửa
  } else {
    films.push(film); // thêm mới
  }

  localStorage.setItem("films", JSON.stringify(films));
  filmForm.reset();
  filmIdInput.value = "";
  renderFilmList();

  // Quay về Home
  window.location.href = "Main.html";
});

// Render danh sách film
function renderFilmList() {
  filmListEl.innerHTML = films
    .map(film => `
      <li class="list-group-item d-flex justify-content-between align-items-center">
        ${film.title} (${film.release}) ⭐${film.rating.toFixed(1)}
        <span>
          <button class="btn btn-sm btn-warning me-2" onclick="editFilm('${film.id}')">Edit</button>
          <button class="btn btn-sm btn-danger" onclick="deleteFilm('${film.id}')">Delete</button>
        </span>
      </li>
    `).join("");
}

// Edit film
function editFilm(id) {
  const film = films.find(f => f.id === id);
  if (film) {
    filmIdInput.value = film.id;
    titleInput.value = film.title;
    releaseInput.value = film.release;
    ratingInput.value = film.rating;
  }
}

// Delete film
function deleteFilm(id) {
  if (confirm("Are you sure to delete this film?")) {
    films = films.filter(f => f.id !== id);
    localStorage.setItem("films", JSON.stringify(films));
    renderFilmList();
  }
}

// Expose functions cho button onclick
window.editFilm = editFilm;
window.deleteFilm = deleteFilm;
