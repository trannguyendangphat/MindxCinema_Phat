const API_KEY = "d24ed55ee6a59e81821ada5a68aed768"; // Thay bằng API TMDB
const BASE_URL = "https://api.themoviedb.org/3";
const IMAGE_URL = "https://image.tmdb.org/t/p/w500";

const movieList = document.getElementById("movie-list");
const container = document.querySelector(".container");

// ================== FETCH PHIM PHỔ BIẾN ==================
async function fetchPopularMovies() {
  try {
    const res = await fetch(`${BASE_URL}/movie/popular?api_key=${API_KEY}&language=en-US&page=1`);
    const data = await res.json();
    displayMovies(data.results);
  } catch (err) {
    movieList.innerHTML = `<p class="text-danger">Error loading movies!</p>`;
  }
}

// ================== HIỂN THỊ MOVIE CARD ==================
function displayMovies(movies) {
  movieList.innerHTML = movies
    .map(
      (movie) => `
    <div class="col-6 col-md-4 col-lg-3">
      <a href="MovieDetail.html?id=${movie.id}" class="text-decoration-none">
        <div class="card h-100 shadow-sm">
          <img src="${IMAGE_URL}${movie.poster_path}" class="card-img-top" alt="${movie.title}">
          <div class="card-body">
            <h5 class="card-title">${movie.title}</h5>
            <p class="card-text small text-muted">⭐ ${movie.vote_average} | ${movie.release_date}</p>
          </div>
        </div>
      </a>
    </div>
  `
    )
    .join("");
}

// ================== TÌM KIẾM PHIM ==================
async function searchMovies(query) {
  try {
    const res = await fetch(`${BASE_URL}/search/movie?api_key=${API_KEY}&language=en-US&query=${encodeURIComponent(query)}&page=1`);
    const data = await res.json();
    if (data.results.length > 0) {
      displayMovies(data.results);
    } else {
      movieList.innerHTML = `<p class="text-warning">No movies found for "${query}"</p>`;
    }
  } catch (err) {
    movieList.innerHTML = `<p class="text-danger">Error searching movies!</p>`;
  }
}

// ================== TẠO FORM TÌM KIẾM ==================
function createSearchForm() {
  const form = document.createElement("form");
  form.className = "mb-4 d-flex";
  form.innerHTML = `
    <input type="text" id="search-input" class="form-control me-2" placeholder="Search movies...">
    <button class="btn btn_form" type="submit">Search</button>
  `;
  container.prepend(form);

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const query = document.getElementById("search-input").value.trim();
    if (query) {
      searchMovies(query);
    }
  });
}

// ================== INIT ==================
function init() {
  createSearchForm();
  fetchPopularMovies();
}

init();
